## Neighborhood Map Project By Haitham.


### This website list best rated restaurant in my city [I will update the list frequently]


### I used the google ,and foursquare API.

### I added filter to make it easy to used.


#### how to use? Just double click on index.html and enjoy, you can all down loaded from Githib.


### Download Neighborhood project and unzip it.

### click index.html to  open in it  in the browser.